rm -f assignment3.zip
zip -r assignment3.zip *.py ./data ./utils
